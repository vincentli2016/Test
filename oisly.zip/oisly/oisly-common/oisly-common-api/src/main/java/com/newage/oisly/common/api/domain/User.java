package com.newage.oisly.common.api.domain;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class User {

    private String id;

    private Integer code;

    private String name;

    private String email;

    private String mobile;

    private Integer buCode;
    private String buName;
    private Integer dept1;
    private String dept1Name;
    private Integer dept2;
    private String dept2Name;
    private Integer dept3;
    private String dept3Name;

    private Integer workpost;

    private String workpostName;

    private Integer leaderLevel;

}
