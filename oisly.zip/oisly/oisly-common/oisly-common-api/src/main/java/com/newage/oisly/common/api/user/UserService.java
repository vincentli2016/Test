package com.newage.oisly.common.api.user;

import com.newage.oisly.common.api.domain.User;
import com.newage.oisly.common.domain.ServiceResponse;

public interface UserService {

    ServiceResponse<Boolean> isAdmin(String userId);

    ServiceResponse<String> getSimulatedUserId(String userId);

    ServiceResponse<User> getUser(String userId);

}
