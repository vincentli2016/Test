package com.newage.oisly.common.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PageRequestBase<T> implements Serializable {

	private static final long serialVersionUID = 3124978289495549101L;

	/**分词搜索*/
	private String searchValue ;

	/**排序方式desc 降序以及 asc 升序*/
    private String orderDir ;

	/**排序的字段key*/
    private String orderKey ;

	/**从第一条开始*/
    private int start = 0;

	/**取多少条*/
    private int length = 10;

	/**总条数*/
    private long results = 0;

	/**结果集*/
    private List<T> rows ;

	/**标识是否分页*/
    private boolean page = true;

}
