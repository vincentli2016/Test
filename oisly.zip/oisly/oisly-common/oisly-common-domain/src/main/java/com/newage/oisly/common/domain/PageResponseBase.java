package com.newage.oisly.common.domain;

import lombok.Data;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Data
public class PageResponseBase<T> implements Serializable {

    private static final long serialVersionUID = -4724436529967369810L;

    /**
     * 总条数
     */
    private long results = 0;
    /**
     * 分页后的结果结果集
     */
    private List<T> rows = new ArrayList<>();

    public PageResponseBase() {
    }

    public PageResponseBase(List<T> rows, PageRequestBase<Object> page) {
        this.rows = rows;
        this.results = page.getResults();
    }
}
