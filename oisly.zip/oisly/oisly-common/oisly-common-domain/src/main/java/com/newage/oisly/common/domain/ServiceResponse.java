package com.newage.oisly.common.domain;

import lombok.Data;

import java.io.Serializable;

@Data
public class ServiceResponse<T> implements Serializable {

    private static final long serialVersionUID = 2488663702267110932L;
    private int code;
    private String msg;
    private String detail;
    private T data;

    public boolean success() {
        return this.code == BaseResponseEnum.SUCCESS.getCode();
    }

    public ServiceResponse() {
    }

    private ServiceResponse(T data, int code, String msg) {
        this.data = data;
        this.code = code;
        this.msg = msg;
    }

    private ServiceResponse(T data, int code, String msg, String detail) {
        this.data = data;
        this.code = code;
        this.msg = msg;
        this.detail = detail;
    }
    public static <T> ServiceResponse<T> ok() {
        return ok(null);
    }

    public static <T> ServiceResponse<T> ok(T data) {
        return ok(data, null);
    }

    public static <T> ServiceResponse<T> ok(T data, String msg) {
        return ok(data, msg, null);
    }

    public static <T> ServiceResponse<T> ok(T data, String msg, String detail) {
        return new ServiceResponse<>(data, BaseResponseEnum.SUCCESS.getCode(), msg, detail);
    }


    public static <T> ServiceResponse<T> fail(T data, int code, String message, String detail) {
        return new ServiceResponse<>(data, code, message, detail);
    }

    public static <T> ServiceResponse<T> fail(T data, int code, String message) {
        return fail(data, code, message, null);
    }

    public static <T> ServiceResponse<T> fail(int code, String message, String detail) {
        return fail(null, code, message, detail);
    }

    public static <T> ServiceResponse<T> fail(int code, String message) {
        return fail(code, message, null);
    }

    public static <T> ServiceResponse<T> fail(String message, String detail) {
        return fail(BaseResponseEnum.FAILURE.getCode(), message, detail);
    }

    public static <T> ServiceResponse<T> fail(String message) {
        return fail(BaseResponseEnum.FAILURE.getCode(), message);
    }

    public static <T> ServiceResponse<T> fail(BaseResponseEnum baseResponseCode) {
        return fail(baseResponseCode.getCode(), baseResponseCode.getMsg(), null);
    }

    public static <T> ServiceResponse<T> fail(BaseResponseEnum baseResponseCode, String detail) {
        return fail(baseResponseCode.getCode(), baseResponseCode.getMsg(), detail);
    }

    public static <T> ServiceResponse<T> fail(T data, String msg) {
        return fail(data, BaseResponseEnum.FAILURE.getCode(), msg, null);
    }

    public static <T> ServiceResponse<T> fail(T data, BaseResponseEnum baseResponseCode) {
        return fail(data, baseResponseCode.getCode(), baseResponseCode.getMsg(), null);
    }

    public static <T> ServiceResponse<T> fail(T data, BaseResponseEnum baseResponseCode, String detail) {
        return fail(data, baseResponseCode.getCode(), baseResponseCode.getMsg(), detail);
    }
}
