package com.newage.oisly.common.vo.process;

import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;

/**
 * @author duanzhiying on 2017/8/3.
 */
public class Constants {
    public static final String DEVELOP_APP_ABSTRACT_INFO_PREFIX = "本地开发应用";
    public static final String DEVELOP_APP_METHOD_INSERT = "INSERT";
    public static final String DEVELOP_APP_METHOD_UPDATE = "UPDATE";


    public static final Integer LIMIT_DIM_DATA = 1000;
    public static final Integer MAX_PAGE_SIZE = 200;
    public static final Integer RELOAD_MAX_SIZE = 150000;
    public static final Integer DEFAULT_PAGE_SIZE = 20;
    public static final Integer DEFAULT_OFFSET = 0;

    /**
     * 预览数据源默认的PAGE SIZE
     */
    public static final Integer PREVIEW_TABLE_PAGE_SIZE = 100;

    public static final String PATTERN_MACRO = "#\\{(.*?)\\}";
    public static final String PATTERN_SQL_PARAM = "\\$\\{(.*?)\\}";

    public static final Pattern PATTERN_LIMIT_1 = Pattern.compile("limit\\s+(\\d+)\\s*,\\s*(\\d+)$", Pattern.CASE_INSENSITIVE);
    public static final Pattern PATTERN_LIMIT_2 = Pattern.compile("limit\\s+(\\d+)\\s+offset\\s+(\\d+)$", Pattern.CASE_INSENSITIVE);
    public static final Pattern PATTERN_LIMIT_3 = Pattern.compile("limit\\s+(\\d+)$", Pattern.CASE_INSENSITIVE);
    public static final Pattern PATTERN_LIMIT_SQL_SERVER_2012 = Pattern.compile("ORDER\\s+BY\\s+([\\s\\S]*)\\s+OFFSET\\s+(\\d+)\\s+ROWS\\s+FETCH\\s+NEXT\\s+(\\d+)\\s+ROWS\\s+ONLY$", Pattern.CASE_INSENSITIVE);
    public static final Pattern PATTERN_ES_CLUSTER_INDEX = Pattern.compile("(godzilla_\\D+)(\\d+)/godzilla_\\D+\\d+/", Pattern.CASE_INSENSITIVE);
    public static final Pattern PATTERN_WHERE = Pattern.compile("where\\s*\\([\\s\\S]*\\)", Pattern.CASE_INSENSITIVE);
    public static final Pattern PATTERN_UPPER_CASE = Pattern.compile(".*[A-Z]+.*");
    public static final Pattern PATTERN_OPERATION = Pattern.compile("sum\\((.*?)\\)|count\\((.*?)\\)|avg\\((.*?)\\)|max\\((.*?)\\)|min\\((.*?)\\)", Pattern.CASE_INSENSITIVE);
    public static final Pattern PATTERN_NUM = Pattern.compile("([1-9]\\d*\\.?\\d*)|(0\\.\\d*[1-9])");
    public static final Pattern PATTERN_END = Pattern.compile("_end$", Pattern.CASE_INSENSITIVE);

    public static final Pattern PATTERN_MACRO_PARAM = Pattern.compile("[\\u4e00-\\u9fa5\\w\\-().*+%,]+\\s*[like=><]+[\\u4e00-\\u9fa5\\w\\-().,% ]*#[\\u4e00-\\u9fa5\\w\\-().,% ]+#[\\d\\-*+%,) ]*", Pattern.CASE_INSENSITIVE);
    public static final Pattern DORIS_CREATE_SQL = Pattern.compile("create\\s+table\\s?([\\w`'\\-]+)\\s+\\(", Pattern.CASE_INSENSITIVE);
    public static final String[] SQL_KEY_WORD = {"table", "database", "select", "delete", "insert", "update"};

    public static final String FIRST_DIM_ORIGIN_VALUE = "firstDimOriginValue";
    public static final String DEFAULT_DIMENSION = "维度";
    public static final String DEFAULT_MEASURE = "度量";

    public static final String ES_TYPE_ORDER = "order";
    public static final String ES_TYPE_FLOW = "flow";
    public static final String ES_TYPE_ORDER_TIME = "createdAt";
    public static final String ES_TYPE_FLOW_TIME = "timeIndex";
    public static final String INDEX_CARD_RATIO = "ratio";

    public static final Integer COMMON_GROUP_ID = 0;

    public static final String QUERY_PARAMS = "queryParams";

    public static final String QUERY_PARAMS_ES = "queryParamsES";

    public static final String DIM_PARAMS = "dimParams";

    /**
     * 移动端过滤组件列表
     */
    public static final List<String> FILTER_COMPONENTS = Arrays.asList(
            "textbox",
            "rect",
            "straightline",
            "image",
            "round",
            "calendar",
            "tabs",
            "button",
            "pivotTable");

    /**
     * 移动端组件是否折叠
     */
    public static final String COLLAPSE = "collapse";

    /**
     * 移动端组件是否显示
     */
    public static final String SHOW_ON_MOBILE = "showOnM";

    /**
     * 移动端组件setting --> layout
     */
    public static final String LAYOUT = "layout";

    /**
     * 移动端指标卡列长度
     */
    public static final String COLUMN = "column";
    public static final String SHOW_COLLAPSE = "showCollapse";
    public static final String SHOW_LANDSCAPE = "showLandscape";

    /**
     * 移动端默认主题
     */
    public static final String DEFAULT_MOBILE_THEME = "light";

    /**
     * 日期组件类型
     */
    public static final String FILTERTYPE_DATEPICKER = "DATEPICKER";
    public static final String DATETYPE_DATE = "date";
    public static final String DATETYPE_DATERANGE = "daterange";
    public static final String DATETYPE_DATETIMERANGE = "datetimerange";
    public static final String DATETYPE_WEEK = "week";
    public static final String DATETYPE_MONTH = "month";
    public static final String DATETYPE_YEAR = "year";

    public static final int DEFAULT_QUERY_SIZE = 10;
    public static final int MAX_QUERY_SIZE = 50_000;
    public static final String LEGEND_OTHER = "其他";

    /**
     * 领航系统
     */
    public static final String LINGHANG = "LINGHANG_";
    public static final String MD5_ALGORITHM = "MD5";
    public static final String LINGHANG_TOKEN_CODE = "linghang_token_code_";

    /**
     * 布尔类型常量
     */
    public static final String BOOLEAN_TRUE = "true";
    public static final String BOOLEAN_FALSE = "false";

    /**
     * 常量值是否
     */
    public static final String CONSTANT_YES = "Yes";
    public static final String CONSTANT_NO = "No";

    /**
     * 左右小括号
     */
    public static final String LEFT_BRACE = "(";
    public static final String RIGHT_BRACE = ")";

    /**
     * 权限中心（不需要复制的属性）
     */
    public static final String[] IGNORE_PROPERTIES = new String[]{"createTime", "applyReason"};

    /**
     * 权限中心（审核通过记录）
     */
    public static final String PASS_NOTE = "通过";

    /**
     * 权限中心（审核驳回记录）
     */
    public static final String REJECT_NOTE = "驳回-";

    /**
     * 权限中心（转交记录）
     */
    public static final String DELIVER_TO_NOTE = "转交-";

    /**
     * 接口返回状态码 0表示成功
     */
    public static final String SUCCESS_CODE = "0";

    /**
     * 默认集市CODE 零售中台
     */
    public static final String DEFAULT_MARKET_CODE = "280";

    /**
     * 默认队列
     */
    public static final Long DEFAULT_QUEUE_ID = 824L;

    /**
     * 走鲸盘下载
     */
    public static final String DOWNLOAD_USE_WHALE = "useWhale";

    public static final String DEFAULT_RATIO = "0.00000000000000000000";
}
