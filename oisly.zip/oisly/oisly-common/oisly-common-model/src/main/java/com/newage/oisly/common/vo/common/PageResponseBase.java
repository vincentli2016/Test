package com.newage.oisly.common.vo.common;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * @author wanghong12
 */
public class PageResponseBase<T>  implements Serializable {


    private static final long serialVersionUID = 3072516229007579620L;

    /**总条数*/
    private long results = 0 ;
    /**分页后的结果结果集*/
    private List<T> rows = new ArrayList<>();


    public PageResponseBase(List<T> rows, PageRequestBase<Object> page) {
        this.rows = rows;
        this.results = page.getResults();
    }
    public PageResponseBase() {}

    public long getResults() {
        return results;
    }

    public List<T> getRows() {
        return rows;
    }

    public void setResults(long results) {
        this.results = results;
    }

    public void setRows(List<T> rows) {
        this.rows = rows;
    }


}
