package com.newage.oisly.common.vo.process;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class JdpDorisModel implements Serializable {

    private static final long serialVersionUID = 4554147206069480150L;

    private Long id;

    private String modelName;

    private String modelDesc;

    private Integer createMode;

    private String createSql;

    private Integer modelStatus;

    private Integer modelType;

    private Integer tableId;

    /**
     * 创建模型 -- 使用已接入表 -- 选择的数据源
     */
    private Long sourceDatabaseId;

    /**
     * 创建模型 -- 使用已接入表 -- 选择的表
     */
    private Long sourceTableId;

    private String creator;

    private String owner;

    private String modifier;

    private Integer deleted = 0;

    private Boolean hasPlumberTask;

    private String plumberTaskName;

    private String targetFileName;

    /**
     * @see com.jd.jdp.common.enums.olap.doris.PlumberJssExtensionTypeEnum
     */
    private Integer extensionNameType;

    private String delimiterStr;

    private Double maxFailRatio;

    private Integer useReferenceTable;

    private Date createTime;

    private Date lastModifyTime;

    private int reportsNum;

    private String createTimeStr;

    private String updateTimeStr;

    private String updateStatus;

    private boolean isEditable;

    /**
     * 配置模式清除前N天数据；0表示不用清除数据；-1表示清除全部数据，其他情况表示清除前N天数据，注意和分区生命周期的关系，该值要小于分区生命周期
     */
    private Integer clearDataBackNDays;
}
