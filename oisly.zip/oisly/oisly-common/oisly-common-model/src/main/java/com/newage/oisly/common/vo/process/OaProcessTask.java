package com.newage.oisly.common.vo.process;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * ClassName:  OaProcessTask     <br/>
 * Function:   Oa流程审批任务vo   <br/>
 * Reason:     TODO ADD Reason     <br/>
 * Date:       2020/2/12 2:34 PM     <br/>
 *
 * @version 1.0.0
 * @See
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class OaProcessTask {
    /**
     *待办任务ID
     */
    private String taskId;
    /**
     *待办任务名称
     */
    private String taskName;
    /**
     *待办人ERP
     */
    private String candidatUsers;
}
