package com.newage.oisly.common.vo.process;


import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;

/**
 * @author duanzhiying on 2017/4/10.
 *
 */
public enum AuthProcessEnum {
    APPLYCONTENT("applyContent","申请内容",""),

    APPLYTYPE("applyType","申请类別","","类型","类型"),

    DBID("dbId","数据ID","应用ID"),

    DBNAME("dbName","连接名称","应用名称","","","模型名称"),

    RECEIVEERP("receiveErp","接收ERP",""),

    APPLYREASON("applyReason","申请原因","",""),

    APPLYERP("applyErp","申请ERP",""),

    STATUS("status","状态",""),

    AUDITERP("auditErp","审核ERP",""),

    DELIVERCONTENT("deliverContent","转交内容",""),

    ITEMID("itemId","应用ID","","数据源ID","表名ID","模型ID"),

    ITEMCODE("itemCode","应用编号","","数据源编号","表名编号","模型编号"),

    ITEMNAME("itemName","应用名称","","数据源","表名","模型名称"),
    
    ITEMOWNER("itemOwner","负责人","");

    private String key;
    private String defaultValue;
    private String[] values;

    AuthProcessEnum(String key, String defaultValue, String... values) {
        this.key = key;
        this.defaultValue = defaultValue;
        //对应AuthApplyEnum的文案展示
        this.values = values;
    }

    public String getKey() {
        return key;
    }

    public String getDeafultValue() {
        return defaultValue;
    }

    public String[] getValues() {
        return values;
    }

    public static AuthProcessEnum getObj(String key) {
        for (AuthProcessEnum item : AuthProcessEnum.values()) {
            if (item.getKey().equals(key)) {
                return item;
            }
        }
        return null;
    }

    public static String getDefaultValue(String key){
        AuthProcessEnum obj = getObj(key);
        return obj != null?obj.getDeafultValue():null;
    }

    public static String getValue(String key,int index){
        AuthProcessEnum obj = getObj(key);
        String[] arr = obj.getValues();
        if(ArrayUtils.isEmpty(arr)){
            return obj != null?obj.getDeafultValue():null;
        }
        if(index>=arr.length || index < 0){
            return obj.getDeafultValue();
        }
        return StringUtils.isBlank(arr[index]) ? obj.getDeafultValue() : arr[index];
    }

}
