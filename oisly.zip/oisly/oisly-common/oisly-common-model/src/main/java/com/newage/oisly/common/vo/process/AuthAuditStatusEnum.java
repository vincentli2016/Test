package com.newage.oisly.common.vo.process;

/**
 * @author zhangxianglong1
 * @date 2019-09-05
 */
public enum AuthAuditStatusEnum {

    PROCESSING(Byte.valueOf("0"), "审批中"),
    PASS(Byte.valueOf("1"), "已通过"),
    REJECT(Byte.valueOf("2"), "已驳回"),
    CANCEL(Byte.valueOf("3"), "已撤回"),
    PLUS_SIGN(Byte.valueOf("4"), "已加签"),
    DELIVER(Byte.valueOf("5"), "已转交");

    private Byte    key;
    private String value;

    AuthAuditStatusEnum(Byte key, String value) {
        this.key = key;
        this.value = value;
    }

    public Byte getKey() {
        return key;
    }

    public String getValue() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static AuthAuditStatusEnum fromValue(String text) {
        for (AuthAuditStatusEnum apply : AuthAuditStatusEnum.values()) {
            if (String.valueOf(apply.value).equals(text)) {
                return apply;
            }
        }
        return null;
    }

    public static AuthAuditStatusEnum fromKey(Byte key) {
        for (AuthAuditStatusEnum apply : AuthAuditStatusEnum.values()) {
            if (apply.key.equals(key)) {
                return apply;
            }
        }
        return null;
    }

    public static void main(String[] args) {
        Byte key = Byte.valueOf("2");
        final AuthAuditStatusEnum authAuditStatusEnum = fromKey(key);
        switch (authAuditStatusEnum) {
            /**
             * 驳回
             */
            case REJECT:
                System.out.println(111);
                break;
            /**
             * 通过
             */
            case PASS:
                System.out.println(222);
                break;
            /**
             * 转交按钮（将当前已提交的申请，转交到其他人审批）
             */
            case DELIVER:
                System.out.println(33);
                break;
            default:
                System.out.println(444);
                break;
        }
    }

}
