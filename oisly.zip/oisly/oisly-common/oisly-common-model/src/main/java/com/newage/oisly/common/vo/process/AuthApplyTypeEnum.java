package com.newage.oisly.common.vo.process;

/**
 * @author zhangxianglong1
 * @date 2019-08-20
 */
public enum AuthApplyTypeEnum {
    /**
     * 应用查看权限
     */
    APP_VIEW(Byte.valueOf("0"), "应用查看权限"),

    /**
     * 应用编辑权限
     */
    APP_OWNER(Byte.valueOf("1"), "应用编辑权限"),

    /**
     * olap使用权限
     */
    OLAP_USE(Byte.valueOf("2"), "JD_OLAP模型使用权限"),

    /**
     * olap编辑权限
     */
    OLAP_OWNER(Byte.valueOf("3"), "JD_OLAP模型编辑权限"),

    /**
     * 数据源
     */
    DATA_SOURCE(Byte.valueOf("4"), "数据源使用权限"),

    /**
     * 表
     */
    TABLE(Byte.valueOf("5"), "表使用权限"),

    /**
     * 转交
     */
    DELIVER_TO(Byte.valueOf("9"), "负责人权限转交");

    private Byte key;
    private String  value;

    AuthApplyTypeEnum(Byte key, String value) {
        this.key = key;
        this.value = value;
    }

    public Byte getKey() {
        return key;
    }

    public String getValue() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static AuthApplyTypeEnum fromValue(String text) {
        for (AuthApplyTypeEnum apply : AuthApplyTypeEnum.values()) {
            if (String.valueOf(apply.value).equals(text)) {
                return apply;
            }
        }
        return null;
    }

    public static AuthApplyTypeEnum fromKey(Byte key) {
        for (AuthApplyTypeEnum apply : AuthApplyTypeEnum.values()) {
            if (apply.key.equals(key)) {
                return apply;
            }
        }
        return null;
    }
}
