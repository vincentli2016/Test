package com.newage.oisly.common.vo.process;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * ClassName:  OaProcessConfirm     <br/>
 * Function:   审批确认，取消vo   <br/>
 * Reason:     TODO ADD Reason     <br/>
 * Date:       2020/2/12 2:57 PM     <br/>
 *
 * @version 1.0.0
 * @See
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class OaProcessConfirm extends OaProcessResult {

    /**
     * 流程状态(0:未完成 1:已完成
     */
    private String processStatus;
}
