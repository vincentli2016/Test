package com.newage.oisly.common.vo.process;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 权限申请-Request
 *
 * @author zhangxianglong1
 * @date 2019-08-20
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class JdpAuthApplyRequest {

    /**
     * 申请内容
     */
    private String  applyContent;

    /**
     * 申请类型
     */
    private Byte    applyType;

    /**
     * 数据连接ID
     */
    private Long    dbId;

    /**
     * 数据连接名称
     */
    private String  dbName;

    /**
     * 接收ERP
     */
    private String  receiveErp;

    /**
     * 申请原因
     */
    private String  applyReason;

    /**
     * 申请ERP
     */
    private String  applyErp;

    /**
     * 状态
     */
    private Byte    status;

    /**
     * 审核ERP
     */
    private String  auditErp;

    /**
     * 转交内容
     */
    private String  deliverContent;

    /**
     * 申请项目
     */
    private List<JdpApplyItem> applyItems;
}
