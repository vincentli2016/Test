package com.newage.oisly.common.vo.process;

/**
 * @author zhangxianglong1
 * @date 2019-08-20
 */
public enum AuthApplyEnum {
    APPLICATION("0","application","应用申请"),

    TABLE("1","table","表申请"),

    DATA_SOURCE("2","data_source","数据源申请"),

    OLAP("3","olap","JD_OLAP模型申请"),

    DELIVER_TO("4","deliver_to","权限交接申请"),

    JD_INSIGHT("5","JD_OLAP模型","JD_OLAP模型申请");



    private String code;
    private String value;
    private String msg;

    AuthApplyEnum(String code, String value, String msg) {
        this.code = code;
        this.value = value;
        this.msg = msg;
    }

    public String getValue() {
        return value;
    }

    public String getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static AuthApplyEnum fromValue(String value) {
        for (AuthApplyEnum apply : AuthApplyEnum.values()) {
            if (String.valueOf(apply.value).equals(value)) {
                return apply;
            }
        }
        return null;
    }
}
