package com.newage.oisly.common.vo.usergroup;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserGroupRequest {

    /**
     * 应用id
     */
    private Integer sysId;

    /**
     * 操作对象
     */
    private String operator;

    private List<UserGroupInfo> userGroupInfos;

    private List<UserGroupVO> userGroupVOList;

}
