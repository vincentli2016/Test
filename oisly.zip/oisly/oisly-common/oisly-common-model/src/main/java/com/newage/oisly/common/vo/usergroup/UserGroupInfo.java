package com.newage.oisly.common.vo.usergroup;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserGroupInfo {
    private Long groupId;
    private String groupName;
    private Boolean editable;
    private List<String> groupAccounts;
}
