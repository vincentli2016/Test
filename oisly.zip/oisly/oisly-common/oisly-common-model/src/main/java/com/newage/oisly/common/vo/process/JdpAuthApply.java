package com.newage.oisly.common.vo.process;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * 权限申请-Bean
 *
 * @author zhangxianglong1
 * @date 2019-08-20
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class JdpAuthApply {

    /**
     * 唯一ID
     */
    private Long    id;

    /**
     * 申请项目编号
     */
    private Long    itemId;

    /**
     * 申请项目编号
     */
    private Long    itemCode;

    /**
     * 申请项目名称
     */
    private String  itemName;

    /**
     * 申请内容
     */
    private String  applyContent;

    /**
     * 申请类型
     */
    private Byte    applyType;

    /**
     * 数据连接ID
     */
    private Long    dbId;

    /**
     * 数据连接名称
     */
    private String  dbName;

    /**
     * 接收ERP
     */
    private String  receiveErp;

    /**
     * 申请原因
     */
    private String  applyReason;

    /**
     * 申请ERP
     */
    private String  applyErp;

    /**
     * 状态
     */
    private Byte    status;

    /**
     * 审核ERP
     */
    private String  auditErp;

    /**
     * 转交内容
     */
    private String  deliverContent;

    /**
     * 修改人
     */
    private String modifier;

    /**
     * 申请时间
     */
    private Date    createTime;

    /**
     * 最后修改时间
     */
    private Date    updateTime;

}