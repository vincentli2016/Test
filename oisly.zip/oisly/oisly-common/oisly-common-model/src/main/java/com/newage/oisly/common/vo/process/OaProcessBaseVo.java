package com.newage.oisly.common.vo.process;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * ClassName:  OaProcessRequest     <br/>
 * Function:   Oa审批流程基础vo   <br/>
 * Reason:     TODO ADD Reason     <br/>
 * Date:       2020/2/11 4:12 PM     <br/>
 *
 * @version 1.0.0
 * @See
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class OaProcessBaseVo {

    /**
     *流程key（由流程中心指定，一个流程定义对应一个，生产环境和测试环境会不同）
     */
    private String processkey;

    /**
     *申请单ID
     */
    private String reqId;


}
