package com.newage.oisly.common.vo.common;

import lombok.Data;

import java.io.Serializable;

@Data
public class ServiceResponse<T> implements Serializable {

    private static final long serialVersionUID = 2488663702267110932L;
    private int code;
    private String msg;
    private String detail;
    private T data;

    public static ServiceResponse<BaseResponseEnum> successResponse() {
        return new ServiceResponse<>(BaseResponseEnum.SUCCESS);
    }


    public ServiceResponse() {
        this.code = BaseResponseEnum.SUCCESS.getCode();
        this.msg = BaseResponseEnum.SUCCESS.getMsg();
    }

    public ServiceResponse(T data) {
        this.code = BaseResponseEnum.SUCCESS.getCode();
        this.msg = BaseResponseEnum.SUCCESS.getMsg();
        this.data = data;
    }


    /**
     * 返回值msg自定义
     *
     * @param data
     * @param code
     * @param msg
     */
    public ServiceResponse(T data, int code, String msg) {
        this.data = data;
        this.code = code;
        this.msg = msg;
    }

    public ServiceResponse(T data, int code, String msg, String detail) {
        this.data = data;
        this.code = code;
        this.msg = msg;
        this.detail = detail;
    }

    public ServiceResponse(ResponseCode ResponseCode, String detail) {
        this.code = ResponseCode.getCode();
        this.msg = ResponseCode.getMsg();
        this.detail = detail;
    }

    public static <T> ServiceResponse<T> ok(T data) {
        return new ServiceResponse<T>(data, BaseResponseEnum.SUCCESS.getCode(), BaseResponseEnum.SUCCESS.getMsg());
    }


    /**
     * 自定义返回异常
     *
     * @param data
     * @param msg
     * @param <T>
     * @return
     */
    public static <T> ServiceResponse<T> fail(T data, String msg) {
        return new ServiceResponse<>(data, BaseResponseCode.FAILURE.getCode(), msg);
    }

    /**
     * 标准异常返回
     *
     * @param data
     * @param baseResponseCode
     * @param <T>
     * @return
     */
    public static <T> ServiceResponse<T> fail(T data, BaseResponseCode baseResponseCode) {
        return new ServiceResponse<>(data, baseResponseCode.getCode(), baseResponseCode.getMsg());
    }

    public static <T> ServiceResponse<T> fail(T data, String msg, String detail) {
        return new ServiceResponse<>(data, BaseResponseCode.AUTO.getCode(), msg, detail);
    }

    public static <T> ServiceResponse<T> fail(T data, BaseResponseCode baseResponseCode, String msg) {
        return new ServiceResponse<>(data, baseResponseCode.getCode(), msg);
    }

    public static <T> ServiceResponse<T> fail(BaseResponseCode baseResponseCode, String detail) {
        baseResponseCode = baseResponseCode == null ? BaseResponseCode.FAILURE : baseResponseCode;
        return new ServiceResponse<>(null, baseResponseCode.getCode(), null, detail);
    }

    /**
     * 成功返回
     *
     * @param data
     * @param <T>
     * @return
     */
    public static <T> ServiceResponse<T> success(T data) {
        return new ServiceResponse<T>(data);
    }

    /**
     * 成功不带返回数据
     *
     * @param <T>
     * @return
     */
    public static <T> ServiceResponse<T> success() {
        return new ServiceResponse<T>();
    }

    /**
     * 成功返回自定义msg
     *
     * @param data
     * @param <T>
     * @return
     */
    public static <T> ServiceResponse<T> success(T data, String msg) {
        return new ServiceResponse<T>(data, BaseResponseEnum.SUCCESS.getCode(), msg);
    }
}
