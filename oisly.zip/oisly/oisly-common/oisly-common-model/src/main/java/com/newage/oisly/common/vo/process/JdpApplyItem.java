package com.newage.oisly.common.vo.process;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author zhangxianglong1
 * @date 2019-08-20
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class JdpApplyItem {

    /**
     * 申请项目ID
     */
    private Long   itemId;

    /**
     * 申请项目编号
     */
    private Long    itemCode;

    /**
     * 申请项目名称
     */
    private String itemName;

    /**
     * 申请项目负责人
     */
    private String itemOwner;
}
