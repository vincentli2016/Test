package com.newage.oisly.common.vo.process;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * ClassName:  OaProcessGtasks     <br/>
 * Function:   待办任务vo  <br/>
 * Reason:     TODO ADD Reason     <br/>
 * Date:       2020/2/12 2:40 PM     <br/>
 *
 * @version 1.0.0
 * @See
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class OaProcessGtasks extends OaProcessBaseVo {
    /**
     * 待办任务列表
     */
    private List<OaProcessTask> tasks;
}
