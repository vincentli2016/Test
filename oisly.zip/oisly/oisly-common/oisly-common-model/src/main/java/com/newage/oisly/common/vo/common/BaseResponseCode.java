package com.newage.oisly.common.vo.common;

/**
 * @Description com.jd.xtl.common.response
 * @Author qianhao
 * @Create 2016-10-18 10:36
 */
public enum BaseResponseCode implements ResponseCode {

    SUCCESS(200, "success"),
    FAILURE(201, "fail"),
    USER_NOT_LOGIN(202, "用户未登录"),
    NO_PERMISSION(401, "无此操作权限"),
    NO_RECORD(402, "查询无记录"),
    OBJECT_EXISTED(409,"应用名称已经存在"),
    PARAM_ERROR(501, "参数错误"),
    BUSINESS_ILLEGAL_OP(502, "非法的操作"),
    SESSION_EXPIRED(503, "session失效"),
    UNKNOWN_ERROR(504, "未知错误"),
    UNKNOWN_REQUEST(505,"未知请求"),
    RATE_LIMITE(520,"JSF RPC异常，JSF已限流！"),
    RPC_EXCEPTION(521,"服务调用异常！"),
    DATABASE_OP_FAILURE(506,"数据库操作失败"),
    NO_PARAM(507,"参数为空"),
    QUERY_FAILURE(508,"查询失败"),
    QUERY_TIMEOUT(509,"查询超时"),
    AUTO(999, "自定义异常");

    private int code;
    private String msg;

    private BaseResponseCode(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public static BaseResponseCode convert(int code) {
        for (BaseResponseCode responseCode : BaseResponseCode.values()) {
            if (responseCode.getCode() == code) {
                return responseCode;
            }
        }

        return null;
    }

    @Override
    public int getCode() {
        return this.code;
    }
    @Override
    public String getMsg() {
        return this.msg;
    }

}

