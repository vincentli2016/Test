package com.newage.oisly.common.vo.process;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * ClassName:  OaProcessErp     <br/>
 * Function:   Oa审批流程修改审批人   <br/>
 * Reason:     TODO ADD Reason     <br/>
 * Date:       2020/2/11 4:12 PM     <br/>
 *
 * @version 1.0.0
 * @See
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class OaProcessErp extends OaProcessBaseVo{

    /**
     *修改审批类型 0
     */
    private String changeApproverType;

    /**
     *任务ID
     */
    private String taskId;

    /**
     *原审批人，多个以逗号分隔，与修改后审批人顺序对应
     */
    private String originalUser;

    /**
     *修改后审批人，多个以逗号分隔
     */
    private String submitUserErp;


}
