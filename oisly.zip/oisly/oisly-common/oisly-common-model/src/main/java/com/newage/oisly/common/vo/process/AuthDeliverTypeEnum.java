package com.newage.oisly.common.vo.process;

/**
 * @author zhangxianglong1
 * @date 2019-08-20
 */
public enum AuthDeliverTypeEnum {

    APPLICATION(Byte.valueOf("0"), "application", "应用"),

    TABLE(Byte.valueOf("1"), "table", "表"),

    DATA_SOURCE(Byte.valueOf("2"), "dataSource", "数据源"),

    OLAP(Byte.valueOf("3"), "olap", "OLAP"),

    MAIL(Byte.valueOf("4"), "mail", "邮件"),

    JD_INSIGHT(Byte.valueOf("5"), "jd_insight", "JD_OLAP模型");

    private Byte key;
    private String value;
    private String desc;

    AuthDeliverTypeEnum(Byte key, String value, String desc) {
        this.key = key;
        this.value = value;
        this.desc = desc;
    }

    public Byte getKey() {
        return key;
    }

    public String getValue() {
        return value;
    }

    public String getDesc() {
        return desc;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static AuthDeliverTypeEnum fromValue(String text) {
        for (AuthDeliverTypeEnum apply : AuthDeliverTypeEnum.values()) {
            if (String.valueOf(apply.value).equals(text)) {
                return apply;
            }
        }
        return null;
    }

    public static AuthDeliverTypeEnum fromDesc(String desc) {
        for (AuthDeliverTypeEnum apply : AuthDeliverTypeEnum.values()) {
            if (String.valueOf(apply.desc).equals(desc)) {
                return apply;
            }
        }
        return null;
    }
}
