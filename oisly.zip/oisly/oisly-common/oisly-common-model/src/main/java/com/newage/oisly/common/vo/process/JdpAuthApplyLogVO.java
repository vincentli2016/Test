package com.newage.oisly.common.vo.process;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author zhangxianglong1
 * @date 2019-08-20
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class JdpAuthApplyLogVO {
    private Long id;

    private Long applyId;

    private Long itemId;

    private Long itemCode;

    private String itemName;

    private String applyContent;

    private Byte applyType;

    /**
     * 审核状态
     */
    private Byte status;

    /**
     * 审核状态名称
     */
    private String statusName;

    private String applyErp;

    /**
     *
     */
    private String auditErp;

    private String receiveErp;

    /**
     * 审批意见
     */
    private String applyReason;

    private String createTime;

}