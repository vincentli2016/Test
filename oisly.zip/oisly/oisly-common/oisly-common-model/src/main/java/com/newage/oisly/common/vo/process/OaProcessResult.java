package com.newage.oisly.common.vo.process;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * ClassName:  OaProcessResult     <br/>
 * Function:   审批结果vo   <br/>
 * Reason:     TODO ADD Reason     <br/>
 * Date:       2020/2/12 2:57 PM     <br/>
 *
 * @version 1.0.0
 * @See
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class OaProcessResult extends OaProcessBaseVo {

    /**
     * 任务ID
     */
    private String taskId;

    /**
     * 审批人erp
     */
    private String submitUserErp;

    /**
     * 审批人姓名
     */
    private String submitUserName;

    /**
     * 审批时间(yyyy-MM-dd hh:mm:ss)  必填
     */
    private String submitTime;

    /**
     * 审批结果(1:批准 3:驳回 4:取消)
     */
    private String submitResult;

    /**
     * 审批意见
     */
    private String submitComments;

}
