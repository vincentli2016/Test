package com.newage.oisly.common.vo.process;

import lombok.Data;

import java.util.List;

@Data
public class JdpAuthAuditRequest {

    private List<JdpAuthApply> jdpAuthApplyList;

    private String auditReason;

    private Byte operationType;

    private String receiveErp;

    private String operationErp;
}