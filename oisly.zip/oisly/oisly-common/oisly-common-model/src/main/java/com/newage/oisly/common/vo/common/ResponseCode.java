package com.newage.oisly.common.vo.common;

public interface ResponseCode {

    int getCode();

    String getMsg();

}
