package com.newage.oisly.common.vo.guide;

import lombok.Data;

import java.util.Date;

/**
 * 引导访问记录
 */
@Data
public class JdpGuideVisitRecord {

    private Integer id;

    private String erp;

    private String type;

    private Date createTime;
}
