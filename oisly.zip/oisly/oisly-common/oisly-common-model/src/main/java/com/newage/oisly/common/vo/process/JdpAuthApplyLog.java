package com.newage.oisly.common.vo.process;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * @author zhangxianglong1
 * @date 2019-09-09
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class JdpAuthApplyLog {
    private Long id;

    private Long applyId;

    private Long itemId;

    private Long itemCode;

    private String itemName;

    private String applyContent;

    private Byte applyType;

    /**
     *
     */
    private Byte status;

    private String applyErp;

    /**
     * 审核erp
     */
    private String auditErp;

    private String receiveErp;

    /**
     * 审批意见
     */
    private String applyReason;

    /**
     * 审批时间
     */
    private Date createTime;

}