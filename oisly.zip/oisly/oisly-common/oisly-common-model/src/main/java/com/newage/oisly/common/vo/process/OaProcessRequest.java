package com.newage.oisly.common.vo.process;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

/**
 * ClassName:  OaProcessRequest     <br/>
 * Function:   Oa审批流程申请vo   <br/>
 * Reason:     TODO ADD Reason     <br/>
 * Date:       2020/2/11 4:12 PM     <br/>
 *
 * @version 1.0.0
 * @See
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class OaProcessRequest extends OaProcessGtasks{

    /**
     *申请单主题
     */
    private String reqName;

    /**
     *申请人erp
     */
    private String reqUserErp;

    /**
     *申请人姓名
     */
    private String reqUserName;

    /**
     * 申请时间(yyyy-MM-dd hh:mm:ss)
     */
    private String reqTime;

    /**
     * 申请备注
     */
    private String comments;

    /**
     *申请信息,格式如下
     *
     * {                                                                      //注意此处不是bu s inessData,拼写错误请见谅
     *         "col1": "采购类型:外采",                                                          //系统中所有的业务字段均使用“字段名:字段值”格式
     *         "col2": "预计总金额:5600.89",
     *         "files":                                                                            //附件配置（如果传云存储的地址需要把地址修改成.local）
     *             [
     *                 {
     *                     "fileName": "流程中心资源.pdf",
     *                     "fileUrl": "http://oss.jd.com/oares.pdf"
     *                 }
     *             ],
     *         "businessDetail1": {
     *             "subReqName": "子表1",                                                            //子表1的标题
     *             "subData": [
     *                 {
     *                     "d1": "商品名称:无名锡箔纸",
     *                     "d2": "单价:112.00"
     *                 },
     *                 {
     *                     "d1": "商品名称:无名锡箔纸",
     *                     "d2": "单价:113.00"
     *                 }
     *             ]
     *         },
     *         "businessDetail2": {
     *             "subReqName": "子表2",                                                            //子表2的标题
     *             "subData": [
     *                 {
     *                     "d1": "商品名称:无名锡箔纸",
     *                     "d2": "单价:112.00"
     *                 },
     *                 {
     *                     "d1": "商品名称:无名锡箔纸",
     *                     "d2": "单价:113.00"
     *                 }
     *             ]
     *         }
     *     }
     *
     */
    private Map<String,Object> bussinessData;



}
