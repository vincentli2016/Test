package com.newage.oisly.common.vo.user;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.HashSet;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SearchUserListReply<T> {
    private HashSet<T> exist;
    private HashSet<T> nonExist;
}
